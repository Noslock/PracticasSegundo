#pragma once

template <class CLAVE>
class fDispersion
{
public:
  virtual int dispersion(CLAVE) = 0;
};
